import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createPreferenceStore } from '../preference-store.js';

test('a pick persists across restart and counts once for its ICP', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'script-picks-'));
  try {
    const file = path.join(dir, 'preferences.jsonl');
    const store = createPreferenceStore(file);
    const pair = { a: 'journey', b: 'mechanism' };
    const { id, token } = store.createGeneration('healthcare', pair);
    assert.equal(store.pick({ id, token: '0'.repeat(64), choice: 'B' }).status, 403);
    assert.equal(store.pick({ id, token, choice: 'B' }).ok, true);
    assert.equal(store.pick({ id, token, choice: 'B' }).duplicate, true);
    assert.equal(store.pick({ id, token, choice: 'A' }).status, 409);

    const reloaded = createPreferenceStore(file);
    assert.equal(reloaded.stats('healthcare').mechanism.icpWins, 1);
    assert.equal(reloaded.stats('healthcare').journey.icpN, 1);
    assert.equal(reloaded.stats('publishing').mechanism.icpN, 0);
    assert.equal(reloaded.stats('publishing').mechanism.globalWins, 1);
    const history = fs.readFileSync(file, 'utf8');
    assert.equal(history.includes(token), false);
    assert.equal(history.trim().split('\n').length, 2);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

test('only registered styles can enter a generation', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'script-picks-'));
  try {
    const store = createPreferenceStore(path.join(dir, 'preferences.jsonl'));
    for (let n = 0; n < 20; n++) {
      const pair = store.choosePair('ngo');
      assert.notEqual(pair.a, pair.b);
      assert.ok(['journey', 'mechanism', 'myth', 'before_after', 'countdown', 'mystery', 'qa', 'stakes'].includes(pair.a));
    }
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
